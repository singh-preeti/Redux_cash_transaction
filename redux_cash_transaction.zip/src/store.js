import React from 'react'
function store() {
    return (
      <div>store</div>
    )
  }
  
  export default store